//
//  UIView+BFW.h
//  BFWDrawView
//
//  Created by Tom Brodhurst-Hill on 19/05/2015.
//  Copyright (c) 2015 BareFeetWare. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (BFW)

- (void)applyShadow:(NSShadow *)shadow;

@end
